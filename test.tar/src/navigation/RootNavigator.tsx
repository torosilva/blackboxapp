import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthProvider, useAuth } from '../context/AuthContext';
import { TabProvider } from '../context/TabContext';
import { ActivityIndicator, View, AppState, AppStateStatus } from 'react-native';
import LockScreen from '../components/LockScreen';

// Importa tus pantallas
import HomeScreen from '../screens/HomeScreen';
import SettingsScreen from '../screens/SettingsScreen';
import NewEntryScreen from '../screens/NewEntryScreen';
import EntryDetailScreen from '../screens/EntryDetailScreen';
import LoginScreen from '../auth/LoginScreen';
import SignUpScreen from '../auth/SignUpScreen';
import OnboardingScreen from '../screens/OnboardingScreen';
import WeeklyReportScreen from '../screens/WeeklyReportScreen';
import ChatScreen from '../screens/ChatScreen';
import TermsScreen from '../screens/TermsScreen';
import PrivacyScreen from '../screens/PrivacyScreen';

import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

const Stack = createNativeStackNavigator();

// Un componente wrapper para manejar la lógica de sesión
function AppNavigator() {
    const { user, profile, isLoading } = useAuth();
    const [isLocked, setIsLocked] = React.useState(true);

    // Re-lock app when it goes to background
    const appState = React.useRef(AppState.currentState);

    React.useEffect(() => {
        const subscription = AppState.addEventListener('change', nextAppState => {
            if (
                appState.current.match(/active/) &&
                nextAppState.match(/inactive|background/)
            ) {
                // App moved to background, re-lock
                setIsLocked(true);
            }
            appState.current = nextAppState;
        });

        return () => {
            subscription.remove();
        };
    }, []);

    if (isLoading) {
        console.log('NAVIGATOR: Loading state active');
        // Pantalla de carga (Splash) mientras revisa si hay usuario
        return (
            <View style={{ flex: 1, backgroundColor: '#0B1021', justifyContent: 'center', alignItems: 'center' }}>
                <ActivityIndicator size="large" color="#818cf8" />
            </View>
        );
    }
    console.log('NAVIGATOR: Loading complete, User:', user?.id);

    // Show Biometric Lock only if user is logged in and screen is locked
    if (user && isLocked) {
        const Lock = LockScreen as any;
        return <Lock onUnlock={() => setIsLocked(false)} />;
    }

    // Force Terms acceptance
    if (user && !profile?.accepted_terms_at) {
        const Nav = Stack.Navigator as any;
        return (
            <Nav screenOptions={{ headerShown: false }}>
                <Stack.Screen
                    name="Terms"
                    component={TermsScreen as any}
                    initialParams={{ isMandatory: true }}
                />
            </Nav>
        );
    }

    // Force Privacy acceptance
    if (user && !profile?.accepted_privacy_at) {
        const Nav = Stack.Navigator as any;
        return (
            <Nav screenOptions={{ headerShown: false }}>
                <Stack.Screen
                    name="Privacy"
                    component={PrivacyScreen as any}
                    initialParams={{ isMandatory: true }}
                />
            </Nav>
        );
    }

    const Nav = Stack.Navigator as any;
    return (
        <Nav screenOptions={{ headerShown: false }}>
            {user ? (
                // === RUTAS PRIVADAS (Si está logueado) ===
                <React.Fragment>
                    <Stack.Screen name="Home" component={HomeScreen as any} />
                    <Stack.Screen name="Settings" component={SettingsScreen as any} />
                    <Stack.Screen
                        name="NewEntry"
                        component={NewEntryScreen as any}
                        options={{ presentation: 'modal', animation: 'slide_from_bottom' }}
                    />
                    <Stack.Screen name="EntryDetail" component={EntryDetailScreen as any} />
                    <Stack.Screen name="WeeklyReport" component={WeeklyReportScreen as any} />
                    <Stack.Screen name="Chat" component={ChatScreen as any} />
                    <Stack.Screen name="Terms" component={TermsScreen as any} />
                    <Stack.Screen name="Privacy" component={PrivacyScreen as any} />
                    <Stack.Screen name="Onboarding" component={OnboardingScreen as any} />
                </React.Fragment>
            ) : (
                // === RUTAS PÚBLICAS (Si NO está logueado) ===
                <React.Fragment>
                    <Stack.Screen name="Login" component={LoginScreen as any} />
                    <Stack.Screen name="SignUp" component={SignUpScreen as any} />
                    <Stack.Screen name="Onboarding" component={OnboardingScreen as any} />
                </React.Fragment>
            )}
        </Nav>
    );
}

export default function RootNavigator() {
    console.log('ROOT_NAVIGATOR: Starting rendering...');
    return (
        <GestureHandlerRootView style={{ flex: 1 }}>
            <SafeAreaProvider>
                <AuthProvider>
                    <NavigationContainer>
                        <AppNavigator />
                    </NavigationContainer>
                </AuthProvider>
            </SafeAreaProvider>
        </GestureHandlerRootView>
    );
}
